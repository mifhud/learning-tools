# import the main window object (mw) from ankiqt
from aqt import mw
# import the "show info" tool from utils.py
from aqt.utils import showInfo
# import all of the Qt GUI library
from aqt.qt import *

from time import mktime,time
from datetime import datetime

def epochTodayMidnight():
	n = datetime.now()
	midnight = datetime(n.year, n.month, n.day)
	return mktime(midnight.timetuple())

def deleteRevlog(timeinfo):
#    showInfo("TIME: %d %d" % (timeinfo * 1000, time() * 1000))
	mw.col.db.execute("delete from revlog where id > ?", timeinfo * 1000)

def resetTenYearsAgo():
	deleteRevlog(epochTodayMidnight() - DAY*365*10)

def resetFiveYearsAgo():
	deleteRevlog(epochTodayMidnight() - DAY*365*5)

def resetYearAgo():
	deleteRevlog(epochTodayMidnight() - DAY*365)

def resetMonthAgo():
	deleteRevlog(epochTodayMidnight() - DAY*30)

def resetThreeWeeksAgo():
	deleteRevlog(epochTodayMidnight() - DAY*21)

def resetTwoWeeksAgo():
	deleteRevlog(epochTodayMidnight() - DAY*14)

def resetOneWeekAgo():
	deleteRevlog(epochTodayMidnight() - DAY*7)

def resetYesterday():
	deleteRevlog(epochTodayMidnight() - DAY)

def resetToday():
	deleteRevlog(epochTodayMidnight())

def resetLastHour():
	deleteRevlog(time() - HOUR)


# Day in seconds
DAY = 86400
# Hour in seconds
HOUR = 3600

# Create menu Reset Study
resetStudy = QMenu("Reset Study Stats", mw)
resetLastHourAction = resetStudy.addAction("Last hour")
resetTodayAction = resetStudy.addAction("Today")
resetYesterdayAction = resetStudy.addAction("Yesterday")
resetOneWeekAction = resetStudy.addAction("One Week")
resetTwoWeeksAction = resetStudy.addAction("Two Weeks")
resetThreeWeeksAction = resetStudy.addAction("Three Weeks")
resetMonthAction = resetStudy.addAction("A month ago")
resetYearAction = resetStudy.addAction("A year ago")
resetFiveYearsAction = resetStudy.addAction("Five years ago")
resetTenYearsAction = resetStudy.addAction("Ten years ago")

# set it to call the respective function when the action is clicked
resetLastHourAction.triggered.connect(resetLastHour)
resetTodayAction.triggered.connect(resetToday)
resetYesterdayAction.triggered.connect(resetYesterday)
resetOneWeekAction.triggered.connect(resetOneWeekAgo)
resetTwoWeeksAction.triggered.connect(resetTenYearsAgo)
resetThreeWeeksAction.triggered.connect(resetThreeWeeksAgo)
resetMonthAction.triggered.connect(resetMonthAgo)
resetYearAction.triggered.connect(resetYearAgo)
resetFiveYearsAction.triggered.connect(resetFiveYearsAgo)
resetTenYearsAction.triggered.connect(resetTenYearsAgo)


# and add it to the tools menu
mw.form.menuTools.addMenu(resetStudy)
