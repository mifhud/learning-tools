**Ask For Deck Name**

Default: is **false**, using **default name generation**.

Set to **true** to prompt for a **custom name** when duplicating a deck.


**Duplicate media files**

Default: is **false**, it will **save space** dupilcated deck using same orginal deck media files it.

Set to **true** to prompt for a **copy media files** when duplicating a deck, duplicated deck has its own media files.
