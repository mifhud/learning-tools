import os
import re
import shutil
from anki import collection
from anki.decks import DeckId
from aqt import mw, gui_hooks
from aqt.browser.sidebar import SidebarItemType
from aqt.qt import QAction
from aqt.utils import tooltip, askUser, getText
from uuid import uuid4
from aqt.operations import CollectionOp
from aqt.qt import QMenu

DUPLICATE_DECK_TITLE = 'Duplicate deck'
DELETE_CLONES_TITLE = 'Delete note clones'

# Load configuration
def load_config():
    config_path = mw.addonManager.getConfig(__name__)
    if not config_path:
        config_path = {}
    return config_path

config = load_config()

# Duplicate Media Files
def duplicate_media(col, source_note, destination_note):
    media_manager = col.media
    for field_name, field_value in source_note.items():
        # Extract all media filenames from the note
        media_files = media_manager.files_in_str(source_note.note_type()['id'], field_value)
        for media_file in media_files:
            if media_manager.have(media_file):
                # Create a new filename to avoid overwriting
                new_media_file = f"{uuid4()}_{media_file}"
                source_path = os.path.join(media_manager.dir(), media_file)
                dest_path = os.path.join(media_manager.dir(), new_media_file)
                shutil.copy(source_path, dest_path)
                
                # Replace the old filename in the note's field with the new filename
                destination_note[field_name] = destination_note[field_name].replace(media_file, new_media_file)
    return destination_note

# Duplicate selected deck in place or to supplied destination
def duplicate_deck(parent, refresh_sidebar, source_deck_id, include_subdecks=True, destination_deck_name=None):
    def _duplicate_deck(col, source_deck_id, source_deck_name, destination_deck_name, include_subdecks):
        def _duplicate_notes(source_deck_id, destination_deck_id):
            nonlocal duplicated_note_count
            changes = collection.OpChanges()
            query = f'SELECT DISTINCT nid FROM cards WHERE did = {source_deck_id}'
            for note_id, in col.db.all(query):
                source_note = col.get_note(note_id)
                destination_note = col.new_note(source_note.note_type())
                # Copy fields from source note to destination note
                for field_name, field_value in source_note.items():
                    destination_note[field_name] = field_value
                # Copy tags from source note to destination note
                destination_note.tags = source_note.tags

                # Duplicate media files if the configuration is enabled
                if config.get('duplicate_media_files', False):
                    destination_note = duplicate_media(col, source_note, destination_note)

                changes = col.add_note(destination_note, destination_deck_id)
                duplicated_note_count += 1
            return changes

        changes = collection.OpChanges()
        destination_deck_id = mw.col.decks.add_normal_deck_with_name(destination_deck_name).id
        changes = _duplicate_notes(source_deck_id, destination_deck_id)

        if include_subdecks:
            child_decks = col.decks.children(source_deck_id)
            for child_source_deck_name, child_source_deck_id in child_decks:
                child_destination_deck_name = destination_deck_name + child_source_deck_name[len(source_deck_name):]
                child_destination_deck_id = col.decks.add_normal_deck_with_name(child_destination_deck_name).id
                changes = _duplicate_notes(child_source_deck_id, child_destination_deck_id)

        return changes

    def _on_success(changes):
        refresh_sidebar()
        tooltip(msg=f'Copied {duplicated_note_count} notes from {source_deck_name} to {destination_deck_name}.', parent=parent)

    source_deck_name = mw.col.decks.name(source_deck_id)
    
    # Optionally ask the user for a new deck name if configured
    if config.get('ask_for_deck_name', False):
        new_name, ok = getText(f'Enter a name for the duplicated deck:', parent=parent, default=f'{source_deck_name} - Copy')
        if ok:
            destination_deck_name = new_name

    # Generate a default name if no custom name is provided
    if destination_deck_name is None:
        destination_deck_name = f'{source_deck_name} - Copy'
        index = 2
        while mw.col.decks.by_name(destination_deck_name) is not None:
            destination_deck_name = re.sub(r'- Copy(?: \(\d+\))?$', rf'- Copy ({index})', destination_deck_name)
            index += 1

    duplicated_note_count = 0

    # Automatically start the duplication process without asking the user
    bg_operation = CollectionOp(parent=parent, op=lambda col: _duplicate_deck(col, source_deck_id, source_deck_name, destination_deck_name, include_subdecks))
    bg_operation.run_in_background()
    bg_operation.success(success=_on_success)

# Delete identical notes within supplied deck
def delete_duplicate_notes(parent, refresh_sidebar, deck_id, include_subdecks=True, keep_strategy='oldest'):
    def _delete_duplicates(col, deck_id, include_subdecks, keep_strategy):
        nonlocal deleted_note_count
        nonlocal duplicate_note_ids
        changes = collection.OpChanges()
        deck_ids = ','.join([str(deck_id) for deck_id in col.decks.deck_and_child_ids(deck_id)]) if include_subdecks else str(deck_id)
        query = f'''
        SELECT id, flds FROM notes
        WHERE flds IN (SELECT flds FROM notes GROUP BY flds HAVING COUNT(*) > 1)
            AND id IN (SELECT DISTINCT nid FROM cards WHERE did IN ({deck_ids}))
        ORDER BY notes.flds ASC, notes.mod ASC
        '''
        candidate_notes = []
        for note_id, fields in col.db.all(query):
            if candidate_notes and fields != candidate_notes[-1][1]:
                duplicate_note_ids += [n_id for n_id, _ in (candidate_notes[:-1] if keep_strategy == 'newest' else candidate_notes[1:])]
                candidate_notes = []
            candidate_notes.append((note_id, fields))

        duplicate_note_ids += [n_id for n_id, _ in (candidate_notes[:-1] if keep_strategy == 'newest' else candidate_notes[1:])]
        deleted_note_count = len(duplicate_note_ids)
        return changes

    def _on_success(changes):
        refresh_sidebar()
        if deleted_note_count and askUser(f'Delete {deleted_note_count} note clones?', parent, title=DELETE_CLONES_TITLE):
            changes = mw.col.remove_notes(duplicate_note_ids)
            tooltip(msg=f'Deleted {deleted_note_count} duplicate notes.', parent=parent)

    deleted_note_count = 0
    duplicate_note_ids = []
    bg_operation = CollectionOp(parent=parent, op=lambda col: _delete_duplicates(col, deck_id, include_subdecks, keep_strategy))
    bg_operation.run_in_background()
    bg_operation.success(success=_on_success)

# Add supplied action to menu
def add_action_to_menu(title, action_function, parent, refresh_sidebar, menu, deck_id):
    action = QAction(title, menu)
    action.triggered.connect(lambda: action_function(parent, refresh_sidebar, deck_id))
    menu.addAction(action)
    return menu

# Hook to add to the sidebar context menu
gui_hooks.browser_sidebar_will_show_context_menu.append(
    lambda sidebar, menu, item, idx: add_action_to_menu(
        DUPLICATE_DECK_TITLE, duplicate_deck, sidebar, sidebar.refresh, menu, DeckId(item.id)
    ) if item.item_type == SidebarItemType.DECK else menu
)

gui_hooks.browser_sidebar_will_show_context_menu.append(
    lambda sidebar, menu, item, idx: add_action_to_menu(
        DELETE_CLONES_TITLE, delete_duplicate_notes, sidebar, sidebar.refresh, menu, DeckId(item.id)
    ) if item.item_type == SidebarItemType.DECK else menu
)

# New feature: Adding duplicate deck option to gear menu
def on_deck_browser_will_show_options_menu(menu: QMenu, did: int) -> None:
    duplicate_action = QAction("Duplicate Deck", menu)
    duplicate_action.triggered.connect(lambda: duplicate_deck(mw, mw.deckBrowser.refresh, did))
    menu.addAction(duplicate_action)

# Hook to add the new option to the gear menu
gui_hooks.deck_browser_will_show_options_menu.append(on_deck_browser_will_show_options_menu)
