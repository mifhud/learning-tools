# Deck & Media Duplication

This Anki addon allows you to easily clone existing decks and their subdecks with enhanced options for media duplication and renaming duplicated deck.

![Screenshots](https://postimg.cc/BjQH6KGt)

### Key Features:
✅ **Deck and Subdecks Duplication.
✅ **Tag Duplication
✅ new deck name.
✅**Duplicate new deck Name:**
✅ **User-Friendly:** Access duplication via the click-on gear menu (from the main Anki window).

### Customize:
Customize the addon’s behavior via the config settings, including options for media duplication and deck renaming.

---
This version is a fork of "Deck duplication"
https://ankiweb.net/shared/info/1779572689