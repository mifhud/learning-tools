addon_cssfiles = ["webview_override.css",
                  ]
other_cssfiles = []
cssfiles = addon_cssfiles + other_cssfiles

other_jsfiles = ["jquery-3.5.1.min.js",
                 ]
