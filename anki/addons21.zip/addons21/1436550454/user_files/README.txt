Any files placed in this folder will be preserved when the add-on is upgraded.
this directory will contain the AwesomeTTS sqlite config database.