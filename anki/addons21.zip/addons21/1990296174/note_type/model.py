enhancedModel = {
    "vers": [],
    "name": "Enhanced Cloze 2.1 v2",
    "tags": [],
    "did": 1,
    "usn": -1,
    "flds": [
        {
            "name": "Content",
            "media": [],
            "sticky": False,
            "rtl": False,
            "ord": 0,
            "font": "Arial",
            "size": 20,
        },
        {
            "name": "Note",
            "media": [],
            "sticky": False,
            "rtl": False,
            "ord": 1,
            "font": "Arial",
            "size": 20,
        },
        {
            "name": "Mnemonics",
            "media": [],
            "sticky": False,
            "rtl": False,
            "ord": 2,
            "font": "Arial",
            "size": 20,
        },
        {
            "name": "Extra",
            "media": [],
            "sticky": False,
            "rtl": False,
            "ord": 3,
            "font": "Arial",
            "size": 20,
        },
        {
            "name": "Cloze99",
            "media": [],
            "sticky": True,
            "rtl": False,
            "ord": 4,
            "font": "Arial",
            "size": 1,
        },
    ],
    "sortf": 0,
    "tmpls": [
        {
            "name": "Enhanced Cloze",
            "qfmt": "",
            "did": None,
            "bafmt": "",
            "afmt": "",
            "ord": 0,
            "bqfmt": "",
        }
    ],
    "mod": 1560146886,
    "latexPost": "\\end{document}",
    "type": 1,
    "id": 0,
    "css": "",
    "latexPre": """\\documentclass[12pt]{article}
\\special{papersize=3in,5in}
\\usepackage[utf8]{inputenc}
\\usepackage{amssymb,amsmath}
\\pagestyle{empty}
\\setlength{\\parindent}{0in}
\\begin{document}
""",
}
